import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neural_network import MLPRegressor

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from data.auto_mpg import get_auto_mpg_data
from src.experimentEngine import ExperimentEngine
from src.utils.fuzzyModels import TSKRegressor
from src.utils.rbfModels import RBFRegressor
from src.utils.dataBaseInfo import DatasetInfoGenerator

def performEda(df, outputDir):
    """
    Realiza Análise Exploratória de Dados básica.
    Salva estatísticas descritivas e um mapa de calor de correlação.
    """
    print("\n--- Exploratory Data Analysis: Auto MPG ---")
    
    df.describe().to_csv(f"{outputDir}/descriptiveStats.csv")
    
    plt.figure(figsize=(10, 8))
    numericDf = df.select_dtypes(include=[np.number])
    sns.heatmap(numericDf.corr(), annot=True, cmap='viridis', fmt=".2f")
    plt.title("Correlation Heatmap - Auto MPG")
    plt.savefig(f"{outputDir}/edaCorrelation.png")
    plt.close()

def main():
    datasetName = "auto_mpg"
    outputDir = f"output/{datasetName}"
    os.makedirs(outputDir, exist_ok=True)
    
    df = get_auto_mpg_data()
    performEda(df, outputDir)
    description = "Previsão do consumo de combustível (milhas por galão) de automóveis com base em características técnicas e de fabricação."
    DatasetInfoGenerator.generateDatasetInfo(df, taskType='regression', outputDir=outputDir, description=description, targetColumn='mpg')
    
    X = df.drop(columns=['mpg'])
    y = df['mpg']
    
    modelConfigs = {
        'MLP': {
            'class': MLPRegressor,
            'paramGrid': {
                'hidden_layer_sizes': [(50,), (100,), (50, 25), (100, 50)],
                'activation': ['relu', 'tanh'],
                'solver': ['adam', 'sgd'],
                'alpha': [0.0001, 0.01],
                'learning_rate_init': [0.001, 0.01],
                'max_iter': [1500]
            }
        },
        'RBF': {
            'class': RBFRegressor,
            'paramGrid': {
                'nCenters': [5, 10, 20, 30],
                'gamma': [0.01, 0.1, 1.0, 10.0]
            }
        },
        'TSK_Variation_1': {
            'class': TSKRegressor,
            'paramGrid': {
                'nClusters': [2, 3, 5],
                'm': [1.5, 2.0]
            }
        },
        'TSK_Variation_2': {
            'class': TSKRegressor,
            'paramGrid': {
                'nClusters': [7, 10],
                'm': [2.0, 2.5]
            }
        }
    }
    
    engine = ExperimentEngine(datasetName, taskType='regression')
    engine.runExperiments(X, y, modelConfigs, numRepetitions=21)

if __name__ == "__main__":
    main()
