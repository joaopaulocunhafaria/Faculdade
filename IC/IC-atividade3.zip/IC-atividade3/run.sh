#!/bin/bash

VENV_NAME="venv"

echo ">>> Preparando o ambiente para a Atividade 3 de IC..."

if [ ! -d "$VENV_NAME" ]; then
    echo "--- Criando ambiente virtual ($VENV_NAME) ---"
    python3 -m venv $VENV_NAME
fi

echo "--- Ativando ambiente virtual ---"
source $VENV_NAME/bin/activate

echo "--- Instalando dependências (requirements.txt) ---"
pip install --upgrade pip
pip install -r requirements.txt

echo ">>> Iniciando Experimentos de Redes Neurais e Neuro-Fuzzy"

python3 src/diabetesAnalise.py
python3 src/creditGAnalise.py
python3 src/autoMpgAnalise.py
python3 src/amesHousingAnalise.py

echo "--- Executando Comparação Global Final ---"
python3 src/finalComparison.py

echo ">>> Todos os experimentos concluídos. Os resultados estão na pasta 'output/'."

deactivate
