import pandas as pd
from sklearn.datasets import fetch_openml
import os

def get_diabetes_data():
    """Busca e processa o dataset Diabetes."""
    diabetes = fetch_openml(name='diabetes', version=1, as_frame=True, parser='auto')
    
    df = diabetes.frame
    
    df = df.dropna()
    
    return df

if __name__ == "__main__":
    df = get_diabetes_data()
    print("Diabetes processed shape:", df.shape)
    print(df.head())
