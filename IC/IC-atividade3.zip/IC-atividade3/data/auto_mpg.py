import pandas as pd
from ucimlrepo import fetch_ucirepo
import os

def get_auto_mpg_data():
    """Busca e processa o dataset Auto MPG."""
    auto_mpg = fetch_ucirepo(id=9)
    
    X = auto_mpg.data.features
    y = auto_mpg.data.targets

    df = pd.concat([X, y], axis=1)
    
    if df.isnull().values.any():
        df = df.dropna()
    
    df = pd.get_dummies(df, columns=['origin'], prefix='origin')
    
    return df

if __name__ == "__main__":
    df = get_auto_mpg_data()
    print("Auto MPG processed shape:", df.shape)
    print(df.head())
