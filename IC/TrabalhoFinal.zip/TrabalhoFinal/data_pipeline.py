"""
data_pipeline.py
================
Pipeline de preparação de dados para o Sistema de Recomendação de Culturas Agrícolas.
"""

import os
import sys

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Configurações globais
dirDados = "data"
dirSaida = "output"
dirImgs = "imgs"

for directory in (dirDados, dirSaida, dirImgs):
    os.makedirs(directory, exist_ok=True)

caminhoDados = os.path.join(dirDados, "Crop_recommendation.csv")
seed = 42

features = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
alvo = "label"

sns.set_theme(style="whitegrid")


# @params:
#   caminho: str - Caminho para o arquivo CSV de entrada.
# @returns:
#   pd.DataFrame - DataFrame contendo os dados agrícolas carregados.
def carregar_dados(caminho: str) -> pd.DataFrame:
    if not os.path.exists(caminho):
        sys.exit(
            f"\n[ERRO] Arquivo '{caminho}' não encontrado.\n"
            "Baixe o 'Crop Recommendation Dataset' da Kaggle e coloque o\n"
            f"arquivo CSV na pasta '{dirDados}/':\n"
            "  https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset\n"
        )

    cropDataFrame = pd.read_csv(caminho)

    expectedColumns = set(features + [alvo])
    missingColumns = expectedColumns - set(cropDataFrame.columns)
    if missingColumns:
        sys.exit(
            f"\n[ERRO] Colunas ausentes no CSV: {sorted(missingColumns)}\n"
            f"Colunas encontradas: {list(cropDataFrame.columns)}\n"
        )

    return cropDataFrame


# @params:
#   cropDataFrame: pd.DataFrame - DataFrame com os dados a serem analisados.
# @returns:
#   None
def analise_exploratoria(cropDataFrame: pd.DataFrame) -> None:
    print("=" * 70)
    print("ANÁLISE EXPLORATÓRIA DOS DADOS (EDA)")
    print("=" * 70)
    print(f"\nNúmero de amostras : {cropDataFrame.shape[0]}")
    print(f"Número de atributos: {len(features)} (features) + 1 (alvo)")
    print(f"Variável de saída  : '{alvo}' — {cropDataFrame[alvo].nunique()} classes")

    print("\nValores ausentes por coluna:")
    missingValuesCount = cropDataFrame.isna().sum()
    print(missingValuesCount.to_string())
    if missingValuesCount.sum() == 0:
        print(">> Nenhum valor ausente encontrado.")

    print("\nDistribuição das classes (amostras por cultura):")
    print(cropDataFrame[alvo].value_counts().to_string())
    isBaseBalanced = cropDataFrame[alvo].value_counts().nunique() == 1
    print(f">> Base {'BALANCEADA' if isBaseBalanced else 'DESBALANCEADA'}.")

    print("\nEstatísticas descritivas das features:")
    print(cropDataFrame[features].describe().round(2).to_string())

    # Gráfico 1: histograma + KDE de cada feature
    plotFigure, plotAxes = plt.subplots(2, 4, figsize=(18, 9))
    for plotAxis, featureName in zip(plotAxes.flat, features):
        sns.histplot(cropDataFrame[featureName], kde=True, ax=plotAxis, color="#2c7fb8")
        plotAxis.set_title(f"Distribuição — {featureName}")
    plotAxes.flat[-1].axis("off")
    plotFigure.suptitle("Distribuição das Features", fontsize=16)
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "eda_distribuicao_features.png"), dpi=120)
    plt.close(plotFigure)

    # Gráfico 2: distribuição das classes
    plotFigure, plotAxis = plt.subplots(figsize=(12, 8))
    classOrder = cropDataFrame[alvo].value_counts().index
    sns.countplot(y=cropDataFrame[alvo], order=classOrder, ax=plotAxis, palette="viridis")
    plotAxis.set_title("Número de Amostras por Cultura (Classe)")
    plotAxis.set_xlabel("Contagem")
    plotAxis.set_ylabel("Cultura")
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "eda_distribuicao_classes.png"), dpi=120)
    plt.close(plotFigure)

    # Gráfico 3: matriz de correlação das features
    plotFigure, plotAxis = plt.subplots(figsize=(9, 7))
    correlationMatrix = cropDataFrame[features].corr()
    sns.heatmap(
        correlationMatrix, annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=plotAxis,
        square=True, linewidths=0.5,
    )
    plotAxis.set_title("Matriz de Correlação entre as Features")
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "eda_matriz_correlacao.png"), dpi=120)
    plt.close(plotFigure)

    # Gráfico 4: boxplots das features
    plotFigure, plotAxes = plt.subplots(2, 4, figsize=(18, 9))
    for plotAxis, featureName in zip(plotAxes.flat, features):
        sns.boxplot(y=cropDataFrame[featureName], ax=plotAxis, color="#7fcdbb")
        plotAxis.set_title(f"Boxplot — {featureName}")
    plotAxes.flat[-1].axis("off")
    plotFigure.suptitle("Boxplots das Features (escala e outliers)", fontsize=16)
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "eda_boxplots_features.png"), dpi=120)
    plt.close(plotFigure)

    print(f"\nGráficos de EDA exportados para a pasta '{dirImgs}/':")
    print("  - eda_distribuicao_features.png")
    print("  - eda_distribuicao_classes.png")
    print("  - eda_matriz_correlacao.png")
    print("  - eda_boxplots_features.png")


# @params:
#   cropDataFrame: pd.DataFrame - DataFrame completo com os dados agrícolas.
# @returns:
#   tuple - Matrizes de atributos (treino, validação, teste) e respectivos vetores de classes.
def dividir_dados(cropDataFrame: pd.DataFrame):
    featuresMatrix = cropDataFrame[features]
    targetVector = cropDataFrame[alvo]

    xTrain, xRest, yTrain, yRest = train_test_split(
        featuresMatrix, targetVector, test_size=0.40, stratify=targetVector, random_state=seed
    )

    xVal, xTest, yVal, yTest = train_test_split(
        xRest, yRest, test_size=0.50, stratify=yRest, random_state=seed
    )

    totalSamples = len(cropDataFrame)
    print("\n" + "=" * 70)
    print("DIVISÃO DOS DADOS (estratificada por classe)")
    print("=" * 70)
    print(f"Treino    : {len(xTrain):>5} amostras ({len(xTrain)/totalSamples:.0%})")
    print(f"Validação : {len(xVal):>5} amostras ({len(xVal)/totalSamples:.0%})")
    print(f"Teste     : {len(xTest):>5} amostras ({len(xTest)/totalSamples:.0%})")

    return xTrain, xVal, xTest, yTrain, yVal, yTest


# @params:
#   xTrain: pd.DataFrame - Atributos de treino.
#   xVal: pd.DataFrame - Atributos de validação.
#   xTest: pd.DataFrame - Atributos de teste.
# @returns:
#   tuple - DataFrames escalonados (treino, validação, teste) e o StandardScaler ajustado.
def padronizar(xTrain, xVal, xTest):
    dataScaler = StandardScaler()

    xTrainScaled = pd.DataFrame(
        dataScaler.fit_transform(xTrain), columns=features, index=xTrain.index
    )
    xValScaled = pd.DataFrame(
        dataScaler.transform(xVal), columns=features, index=xVal.index
    )
    xTestScaled = pd.DataFrame(
        dataScaler.transform(xTest), columns=features, index=xTest.index
    )

    print("\n" + "=" * 70)
    print("PADRONIZAÇÃO (Z-score) — scaler ajustado apenas no treino")
    print("=" * 70)
    print("Média (~0) e desvio (~1) no conjunto de treino padronizado:")
    print(xTrainScaled.describe().loc[["mean", "std"]].round(4).to_string())

    return xTrainScaled, xValScaled, xTestScaled, dataScaler


# @params:
#   xData: pd.DataFrame - DataFrame de atributos.
#   yData: pd.Series - Série com as classes.
#   filePath: str - Caminho do arquivo CSV de destino.
# @returns:
#   None
def salvar_conjunto(xData, yData, filePath: str) -> None:
    mergedDataset = xData.copy()
    mergedDataset[alvo] = yData.values
    mergedDataset.to_csv(filePath, index=False)


# @params:
#   None
# @returns:
#   None
def main() -> None:
    cropDataFrame = carregar_dados(caminhoDados)

    analise_exploratoria(cropDataFrame)

    xTrain, xVal, xTest, yTrain, yVal, yTest = dividir_dados(cropDataFrame)

    xTrainScaled, xValScaled, xTestScaled, dataScaler = padronizar(
        xTrain, xVal, xTest
    )

    salvar_conjunto(xTrainScaled, yTrain, os.path.join(dirSaida, "treino.csv"))
    salvar_conjunto(xValScaled, yVal, os.path.join(dirSaida, "validacao.csv"))
    salvar_conjunto(xTestScaled, yTest, os.path.join(dirSaida, "teste.csv"))
    joblib.dump(dataScaler, os.path.join(dirSaida, "scaler.joblib"))

    print("\n" + "=" * 70)
    print("ARQUIVOS GERADOS")
    print("=" * 70)
    print(f"  (pasta '{dirSaida}/')")
    print("  - treino.csv      (60% — padronizado)")
    print("  - validacao.csv   (20% — padronizado)")
    print("  - teste.csv       (20% — padronizado, uso só na avaliação final)")
    print("  - scaler.joblib   (StandardScaler ajustado no treino)")
    print("\nPipeline concluído com sucesso.")


if __name__ == "__main__":
    main()
