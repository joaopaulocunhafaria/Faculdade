"""
train_models.py
================
Treinamento, busca de hiperparâmetros e comparação de modelos de classificação.
"""

import os
import warnings

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings("ignore", category=ConvergenceWarning)

# Configurações globais
features = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
alvo = "label"

seed = 42
sementes = [42, 7, 123]

dirSaida = "output"
dirImgs = "imgs"
for directory in (dirSaida, dirImgs):
    os.makedirs(directory, exist_ok=True)

sns.set_theme(style="whitegrid")


# @params:
#   filePath: str - Caminho do arquivo CSV contendo os dados.
# @returns:
#   tuple - Matriz de atributos e vetor de classes correspondente.
def carregar(filePath: str):
    cropDataFrame = pd.read_csv(filePath)
    return cropDataFrame[features], cropDataFrame[alvo]


# @params:
#   yTrue: pd.Series ou np.ndarray - Vetor contendo as classes reais.
#   yPred: np.ndarray - Vetor contendo as predições do modelo.
# @returns:
#   dict - Dicionário contendo as métricas calculadas.
def calcular_metricas(yTrue, yPred) -> dict:
    return {
        "acuracia": accuracy_score(yTrue, yPred),
        "precisao": precision_score(
            yTrue, yPred, average="macro", zero_division=0
        ),
        "revocacao": recall_score(
            yTrue, yPred, average="macro", zero_division=0
        ),
        "f1": f1_score(
            yTrue, yPred, average="macro", zero_division=0
        ),
    }


# @params:
#   model: BaseEstimator - O classificador a ser ajustado e avaliado.
#   xTrain: pd.DataFrame - Atributos do conjunto de treino.
#   yTrain: pd.Series - Vetores de classe do conjunto de treino.
#   xVal: pd.DataFrame - Atributos do conjunto de validação.
#   yVal: pd.Series - Vetores de classe do conjunto de validação.
# @returns:
#   dict - Dicionário contendo as métricas de validação.
def avaliar_deterministico(model, xTrain, yTrain, xVal, yVal) -> dict:
    model.fit(xTrain, yTrain)
    return calcular_metricas(yVal, model.predict(xVal))


# @params:
#   construtor: callable - Função fábrica que aceita uma semente e retorna um classificador.
#   xTrain: pd.DataFrame - Atributos do conjunto de treino.
#   yTrain: pd.Series - Vetores de classe do conjunto de treino.
#   xVal: pd.DataFrame - Atributos do conjunto de validação.
#   yVal: pd.Series - Vetores de classe do conjunto de validação.
#   sementes: list - Lista de sementes para treinar rodadas independentes.
# @returns:
#   dict - Dicionário com médias e desvios padrão agregados das métricas.
def avaliar_estocastico(construtor, xTrain, yTrain, xVal, yVal, sementes) -> dict:
    metrics = {"acuracia": [], "precisao": [], "revocacao": [], "f1": []}
    for seedValue in sementes:
        model = construtor(seedValue)
        model.fit(xTrain, yTrain)
        for metricKey, metricValue in calcular_metricas(yVal, model.predict(xVal)).items():
            metrics[metricKey].append(metricValue)

    evaluationResult = {}
    for metricKey, metricValues in metrics.items():
        evaluationResult[f"{metricKey}_media"] = float(np.mean(metricValues))
        evaluationResult[f"{metricKey}_desvio"] = float(np.std(metricValues))
    return evaluationResult


# @params:
#   xTrain: pd.DataFrame - Atributos do conjunto de treino.
#   yTrain: pd.Series - Classes do conjunto de treino.
#   xVal: pd.DataFrame - Atributos do conjunto de validação.
#   yVal: pd.Series - Classes do conjunto de validação.
# @returns:
#   pd.DataFrame - DataFrame com os resultados para cada profundidade avaliada.
def experimento_decision_tree(xTrain, yTrain, xVal, yVal) -> pd.DataFrame:
    print("\n" + "=" * 70)
    print("1) DECISION TREE — influência da profundidade (max_depth)")
    print("=" * 70)

    depthList = [3, 5, 7, 10, 15, 20, None]
    resultRows = []
    for maxDepth in depthList:
        model = DecisionTreeClassifier(max_depth=maxDepth, random_state=seed)
        metricsResult = avaliar_deterministico(model, xTrain, yTrain, xVal, yVal)
        metricsResult["max_depth"] = "None" if maxDepth is None else maxDepth
        resultRows.append(metricsResult)

    resultsDataFrame = pd.DataFrame(resultRows)[
        ["max_depth", "acuracia", "precisao", "revocacao", "f1"]
    ]
    print(resultsDataFrame.round(4).to_string(index=False))

    plotFigure, plotAxis = plt.subplots(figsize=(9, 5))
    plotLabels = [str(p) for p in resultsDataFrame["max_depth"]]
    plotAxis.plot(plotLabels, resultsDataFrame["acuracia"], marker="o", label="Acurácia")
    plotAxis.plot(plotLabels, resultsDataFrame["f1"], marker="s", label="F1 (macro)")
    plotAxis.set_title("Decision Tree — impacto da profundidade (validação)")
    plotAxis.set_xlabel("max_depth")
    plotAxis.set_ylabel("Métrica")
    plotAxis.legend()
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "resultado_decision_tree.png"), dpi=120)
    plt.close(plotFigure)

    bestConfig = resultsDataFrame.loc[resultsDataFrame["acuracia"].idxmax()]
    print(
        f">> Melhor profundidade: max_depth={bestConfig['max_depth']} "
        f"(acurácia={bestConfig['acuracia']:.4f})"
    )
    return resultsDataFrame


# @params:
#   xTrain: pd.DataFrame - Atributos do conjunto de treino.
#   yTrain: pd.Series - Classes do conjunto de treino.
#   xVal: pd.DataFrame - Atributos do conjunto de validação.
#   yVal: pd.Series - Classes do conjunto de validação.
# @returns:
#   pd.DataFrame - DataFrame contendo os resultados para os números de estimadores testados.
def experimento_random_forest(xTrain, yTrain, xVal, yVal) -> pd.DataFrame:
    print("\n" + "=" * 70)
    print("2) RANDOM FOREST — variação do nº de estimadores (n_estimators)")
    print("=" * 70)

    estimatorsList = [10, 50, 100, 200, 300]
    resultRows = []
    for numEstimators in estimatorsList:
        metricsResult = avaliar_estocastico(
            lambda s, n=numEstimators: RandomForestClassifier(n_estimators=n, random_state=s),
            xTrain, yTrain, xVal, yVal, sementes,
        )
        metricsResult["n_estimators"] = numEstimators
        resultRows.append(metricsResult)

    resultsDataFrame = pd.DataFrame(resultRows)
    dfColumns = ["n_estimators", "acuracia_media", "acuracia_desvio",
                 "f1_media", "f1_desvio"]
    print(resultsDataFrame[dfColumns].round(4).to_string(index=False))

    plotFigure, plotAxis = plt.subplots(figsize=(9, 5))
    plotAxis.errorbar(
        resultsDataFrame["n_estimators"], resultsDataFrame["acuracia_media"], yerr=resultsDataFrame["acuracia_desvio"],
        marker="o", capsize=4, label="Acurácia",
    )
    plotAxis.set_title("Random Forest — impacto do nº de estimadores (validação)")
    plotAxis.set_xlabel("n_estimators")
    plotAxis.set_ylabel("Acurácia (média ± desvio)")
    plotAxis.legend()
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "resultado_random_forest.png"), dpi=120)
    plt.close(plotFigure)

    bestConfig = resultsDataFrame.loc[resultsDataFrame["acuracia_media"].idxmax()]
    print(
        f">> Melhor configuração: n_estimators={int(bestConfig['n_estimators'])} "
        f"(acurácia={bestConfig['acuracia_media']:.4f} ± {bestConfig['acuracia_desvio']:.4f})"
    )
    return resultsDataFrame


# @params:
#   xTrain: pd.DataFrame - Atributos do conjunto de treino.
#   yTrain: pd.Series - Classes do conjunto de treino.
#   xVal: pd.DataFrame - Atributos do conjunto de validação.
#   yVal: pd.Series - Classes do conjunto de validação.
# @returns:
#   pd.DataFrame - DataFrame com os resultados de todas as combinações de rede neural.
def experimento_mlp(xTrain, yTrain, xVal, yVal) -> pd.DataFrame:
    print("\n" + "=" * 70)
    print("3) MLP — neurônios/camadas, taxa de aprendizado e nº de épocas")
    print("=" * 70)

    architecturesList = [(50,), (100,), (100, 50), (50, 50)]
    learningRatesList = [0.001, 0.01]
    epochsList = [200, 500]

    resultRows = []
    for hiddenLayers in architecturesList:
        for learningRate in learningRatesList:
            for maxEpochs in epochsList:
                metricsResult = avaliar_estocastico(
                    lambda s, arq=hiddenLayers, lr=learningRate, ep=maxEpochs: MLPClassifier(
                        hidden_layer_sizes=arq,
                        learning_rate_init=lr,
                        max_iter=ep,
                        early_stopping=False,
                        random_state=s,
                    ),
                    xTrain, yTrain, xVal, yVal, sementes,
                )
                metricsResult["arquitetura"] = str(hiddenLayers)
                metricsResult["taxa_aprend"] = learningRate
                metricsResult["epocas"] = maxEpochs
                resultRows.append(metricsResult)

    resultsDataFrame = pd.DataFrame(resultRows)
    dfColumns = ["arquitetura", "taxa_aprend", "epocas",
                 "acuracia_media", "acuracia_desvio", "f1_media"]
    print(resultsDataFrame[dfColumns].round(4).to_string(index=False))

    resultsDataFrame["config"] = (
        resultsDataFrame["arquitetura"] + " | lr=" + resultsDataFrame["taxa_aprend"].astype(str)
        + " | ep=" + resultsDataFrame["epocas"].astype(str)
    )
    plotFigure, plotAxis = plt.subplots(figsize=(12, 7))
    sortedDataFrame = resultsDataFrame.sort_values("acuracia_media")
    plotAxis.barh(sortedDataFrame["config"], sortedDataFrame["acuracia_media"],
              xerr=sortedDataFrame["acuracia_desvio"], capsize=3, color="#41b6c4")
    plotAxis.set_title("MLP — impacto das configurações (validação)")
    plotAxis.set_xlabel("Acurácia (média ± desvio)")
    plotFigure.tight_layout()
    plotFigure.savefig(os.path.join(dirImgs, "resultado_mlp.png"), dpi=120)
    plt.close(plotFigure)

    bestConfig = resultsDataFrame.loc[resultsDataFrame["acuracia_media"].idxmax()]
    print(
        f">> Melhor configuração: arquitetura={bestConfig['arquitetura']}, "
        f"lr={bestConfig['taxa_aprend']}, épocas={int(bestConfig['epocas'])} "
        f"(acurácia={bestConfig['acuracia_media']:.4f} ± {bestConfig['acuracia_desvio']:.4f})"
    )
    return resultsDataFrame


# @params:
#   None
# @returns:
#   None
def main() -> None:
    xTrain, yTrain = carregar(os.path.join(dirSaida, "treino.csv"))
    xVal, yVal = carregar(os.path.join(dirSaida, "validacao.csv"))

    print("=" * 70)
    print("TREINAMENTO E BUSCA DE HIPERPARÂMETROS (avaliação na validação)")
    print("=" * 70)
    print(f"Treino    : {len(xTrain)} amostras")
    print(f"Validação : {len(xVal)} amostras")
    print(f"Repetições (modelos estocásticos): {len(sementes)} sementes {sementes}")

    resultsDecisionTree = experimento_decision_tree(xTrain, yTrain, xVal, yVal)
    resultsRandomForest = experimento_random_forest(xTrain, yTrain, xVal, yVal)
    resultsMlp = experimento_mlp(xTrain, yTrain, xVal, yVal)

    resultsDecisionTree.to_csv(os.path.join(dirSaida, "validacao_decision_tree.csv"), index=False)
    resultsRandomForest.to_csv(os.path.join(dirSaida, "validacao_random_forest.csv"), index=False)
    resultsMlp.to_csv(os.path.join(dirSaida, "validacao_mlp.csv"), index=False)

    bestDecisionTree = resultsDecisionTree.loc[resultsDecisionTree["acuracia"].idxmax()]
    bestDepth = None if bestDecisionTree["max_depth"] == "None" else int(bestDecisionTree["max_depth"])
    modelDecisionTree = DecisionTreeClassifier(max_depth=bestDepth, random_state=seed).fit(xTrain, yTrain)

    bestRandomForest = resultsRandomForest.loc[resultsRandomForest["acuracia_media"].idxmax()]
    modelRandomForest = RandomForestClassifier(
        n_estimators=int(bestRandomForest["n_estimators"]), random_state=seed
    ).fit(xTrain, yTrain)

    bestMlp = resultsMlp.loc[resultsMlp["acuracia_media"].idxmax()]
    bestArchitecture = tuple(int(x) for x in bestMlp["arquitetura"].strip("()").rstrip(",").split(","))
    modelMlp = MLPClassifier(
        hidden_layer_sizes=bestArchitecture,
        learning_rate_init=float(bestMlp["taxa_aprend"]),
        max_iter=int(bestMlp["epocas"]),
        early_stopping=False,
        random_state=seed,
    ).fit(xTrain, yTrain)

    joblib.dump(modelDecisionTree, os.path.join(dirSaida, "modelo_decision_tree.joblib"))
    joblib.dump(modelRandomForest, os.path.join(dirSaida, "modelo_random_forest.joblib"))
    joblib.dump(modelMlp, os.path.join(dirSaida, "modelo_mlp.joblib"))

    summaryDataFrame = pd.DataFrame([
        {"modelo": "Decision Tree",
         "config": f"max_depth={bestDecisionTree['max_depth']}",
         "acuracia_val": bestDecisionTree["acuracia"]},
        {"modelo": "Random Forest",
         "config": f"n_estimators={int(bestRandomForest['n_estimators'])}",
         "acuracia_val": bestRandomForest["acuracia_media"]},
        {"modelo": "MLP",
         "config": f"arq={bestMlp['arquitetura']}, lr={bestMlp['taxa_aprend']}, ep={int(bestMlp['epocas'])}",
         "acuracia_val": bestMlp["acuracia_media"]},
    ])
    summaryDataFrame.to_csv(os.path.join(dirSaida, "resumo_validacao.csv"), index=False)

    print("\n" + "=" * 70)
    print("RESUMO — melhor configuração de cada algoritmo (validação)")
    print("=" * 70)
    print(summaryDataFrame.round(4).to_string(index=False))

    print("\nArquivos gerados:")
    print("  - validacao_decision_tree.csv / _random_forest.csv / _mlp.csv")
    print("  - resultado_decision_tree.png / _random_forest.png / _mlp.png")
    print("  - resumo_validacao.csv")
    print("  - modelo_decision_tree.joblib / _random_forest.joblib / _mlp.joblib")
    print("\nTreinamento concluído. Modelos prontos para a avaliação no teste.")


if __name__ == "__main__":
    main()
