import os
import warnings

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings("ignore", category=ConvergenceWarning)

# Configurações globais
features = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
alvo = "label"

seed = 42
sementes = [42, 7, 123, 2024, 99, 1, 55, 88, 314, 271]

dirSaida = "output"
dirImgs = "imgs"
for directory in (dirSaida, dirImgs):
    os.makedirs(directory, exist_ok=True)

sns.set_theme(style="whitegrid")


# @params:
#   filePath: str - Caminho do arquivo CSV de entrada.
# @returns:
#   tuple - Matriz de atributos e vetor de classes correspondente.
def carregar(filePath: str):
    cropDataFrame = pd.read_csv(filePath)
    return cropDataFrame[features], cropDataFrame[alvo]


# @params:
#   depthValue: any - Valor de profundidade lido do arquivo.
# @returns:
#   int ou None - Profundidade convertida para inteiro ou None se for string "None".
def _parse_max_depth(depthValue):
    return None if str(depthValue) == "None" else int(float(depthValue))


# @params:
#   architectureText: str - Representação textual das camadas ocultas.
# @returns:
#   tuple - Tupla de inteiros correspondente à arquitetura das camadas.
def _parse_arquitetura(architectureText: str) -> tuple:
    cleanedText = str(architectureText).strip("()").rstrip(",")
    return tuple(int(x) for x in cleanedText.split(",") if x.strip())


# @params:
#   None
# @returns:
#   dict - Dicionário de construtores de classificadores com hiperparâmetros ajustados.
def construtores_melhores_modelos() -> dict:
    dtResults = pd.read_csv(os.path.join(dirSaida, "validacao_decision_tree.csv"))
    bestDt = dtResults.loc[dtResults["acuracia"].idxmax()]
    maxDepth = _parse_max_depth(bestDt["max_depth"])

    rfResults = pd.read_csv(os.path.join(dirSaida, "validacao_random_forest.csv"))
    bestRf = rfResults.loc[rfResults["acuracia_media"].idxmax()]
    nEstimators = int(bestRf["n_estimators"])

    mlpResults = pd.read_csv(os.path.join(dirSaida, "validacao_mlp.csv"))
    bestMlp = mlpResults.loc[mlpResults["acuracia_media"].idxmax()]
    hiddenLayers = _parse_arquitetura(bestMlp["arquitetura"])
    learningRate = float(bestMlp["taxa_aprend"])
    epochs = int(bestMlp["epocas"])

    return {
        "Decision Tree": (
            lambda s: DecisionTreeClassifier(max_depth=maxDepth, random_state=s),
            f"max_depth={bestDt['max_depth']}",
        ),
        "Random Forest": (
            lambda s: RandomForestClassifier(n_estimators=nEstimators, random_state=s),
            f"n_estimators={nEstimators}",
        ),
        "MLP": (
            lambda s: MLPClassifier(
                hidden_layer_sizes=hiddenLayers,
                learning_rate_init=learningRate,
                max_iter=epochs,
                early_stopping=False,
                random_state=s,
            ),
            f"arq={hiddenLayers}, lr={learningRate}, epocas={epochs}",
        ),
    }


# @params:
#   yTrue: pd.Series ou np.ndarray - Classes reais.
#   yPred: np.ndarray - Classes previstas.
# @returns:
#   dict - Dicionário com as métricas de avaliação.
def calcular_metricas(yTrue, yPred) -> dict:
    return {
        "acuracia": accuracy_score(yTrue, yPred),
        "precisao": precision_score(
            yTrue, yPred, average="macro", zero_division=0
        ),
        "revocacao": recall_score(
            yTrue, yPred, average="macro", zero_division=0
        ),
        "f1": f1_score(
            yTrue, yPred, average="macro", zero_division=0
        ),
    }


# @params:
#   yTrue: pd.Series ou np.ndarray - Classes reais.
#   yPred: np.ndarray - Classes previstas.
#   classNames: list - Nome de todas as classes avaliadas.
#   modelName: str - Nome do classificador avaliado.
#   filePath: str - Caminho para salvar a figura gerada.
# @returns:
#   None
def salvar_matriz_confusao(yTrue, yPred, classNames, modelName, filePath):
    confMatrix = confusion_matrix(yTrue, yPred, labels=classNames)
    plotFigure, plotAxis = plt.subplots(figsize=(13, 11))
    sns.heatmap(
        confMatrix, annot=True, fmt="d", cmap="Blues",
        xticklabels=classNames, yticklabels=classNames, ax=plotAxis,
        cbar_kws={"label": "Nº de amostras"}
    )
    plotAxis.set_title(f"Matriz de Confusão — {modelName} (conjunto de teste)",fontsize=13)
    plotAxis.set_xlabel("Classe prevista",fontsize=13)
    plotAxis.set_ylabel("Classe verdadeira",fontsize=13)
    plt.setp(plotAxis.get_xticklabels(), rotation=90, fontsize=13)
    plt.setp(plotAxis.get_yticklabels(), rotation=0, fontsize=13)
    plotFigure.tight_layout()
    plotFigure.savefig(filePath, dpi=120)
    plt.close(plotFigure)


# @params:
#   None
# @returns:
#   None
def main() -> None:
    xTrain, yTrain = carregar(os.path.join(dirSaida, "treino.csv"))
    xTest, yTest = carregar(os.path.join(dirSaida, "teste.csv"))
    classNames = sorted(yTrain.unique())

    print("=" * 70)
    print("AVALIAÇÃO FINAL NO CONJUNTO DE TESTE (20%)")
    print("=" * 70)
    print(f"Treino : {len(xTrain)} amostras")
    print(f"Teste  : {len(xTest)} amostras  |  {len(classNames)} classes")
    print(f"Execuções por modelo (aleatoriedade): {len(sementes)} sementes")

    bestModels = construtores_melhores_modelos()

    executionLogs = []
    aggregatedResults = []

    for modelName, (modelFactory, configDescription) in bestModels.items():
        print("\n" + "-" * 70)
        print(f"Modelo: {modelName}  |  Configuração: {configDescription}")
        print("-" * 70)

        metricsPerExecution = {"acuracia": [], "precisao": [],
                                 "revocacao": [], "f1": []}

        for seedValue in sementes:
            model = modelFactory(seedValue)
            model.fit(xTrain, yTrain)
            yPredicted = model.predict(xTest)
            metricsResult = calcular_metricas(yTest, yPredicted)
            for metricKey, metricValue in metricsResult.items():
                metricsPerExecution[metricKey].append(metricValue)
            executionLogs.append({
                "modelo": modelName, "semente": seedValue, **metricsResult,
            })

        aggregatedRow = {"modelo": modelName, "configuracao": configDescription,
                    "n_execucoes": len(sementes)}
        for metricKey, metricValues in metricsPerExecution.items():
            aggregatedRow[f"{metricKey}_media"] = float(np.mean(metricValues))
            aggregatedRow[f"{metricKey}_desvio"] = float(np.std(metricValues))
        aggregatedResults.append(aggregatedRow)

        print(
            f"Acurácia : {aggregatedRow['acuracia_media']:.4f} ± {aggregatedRow['acuracia_desvio']:.4f}\n"
            f"Precisão : {aggregatedRow['precisao_media']:.4f} ± {aggregatedRow['precisao_desvio']:.4f}\n"
            f"Revocação: {aggregatedRow['revocacao_media']:.4f} ± {aggregatedRow['revocacao_desvio']:.4f}\n"
            f"F1-score : {aggregatedRow['f1_media']:.4f} ± {aggregatedRow['f1_desvio']:.4f}"
        )

        baseModel = modelFactory(seed)
        baseModel.fit(xTrain, yTrain)
        confMatrixFilePath = os.path.join(
            dirImgs, f"matriz_confusao_{modelName.lower().replace(' ', '_')}.png"
        )
        salvar_matriz_confusao(
            yTest, baseModel.predict(xTest), classNames, modelName, confMatrixFilePath
        )
        print(f"Matriz de confusão salva em: {confMatrixFilePath}")

    dfExecutions = pd.DataFrame(executionLogs)
    dfExecutions.to_csv(
        os.path.join(dirSaida, "resultados_teste_execucoes.csv"), index=False
    )

    aggregatedColumns = [
        "modelo", "configuracao", "n_execucoes",
        "acuracia_media", "acuracia_desvio",
        "precisao_media", "precisao_desvio",
        "revocacao_media", "revocacao_desvio",
        "f1_media", "f1_desvio",
    ]
    dfAggregated = pd.DataFrame(aggregatedResults)[aggregatedColumns]
    dfAggregated.to_csv(os.path.join(dirSaida, "resultados_teste.csv"), index=False)

    print("\n" + "=" * 70)
    print("COMPARAÇÃO FINAL DOS MODELOS (teste — média ± desvio)")
    print("=" * 70)
    print(dfAggregated[
        ["modelo", "acuracia_media", "acuracia_desvio", "f1_media", "f1_desvio"]
    ].round(4).to_string(index=False))

    bestModel = dfAggregated.loc[dfAggregated["acuracia_media"].idxmax()]
    print(
        f"\n>> Melhor desempenho no teste: {bestModel['modelo']} "
        f"(acurácia={bestModel['acuracia_media']:.4f} ± {bestModel['acuracia_desvio']:.4f})"
    )

    print("\nArquivos gerados:")
    print("  - resultados_teste_execucoes.csv (métricas de cada execução)")
    print("  - resultados_teste.csv           (média ± desvio por modelo)")
    print("  - matriz_confusao_decision_tree.png / _random_forest.png / _mlp.png")


if __name__ == "__main__":
    main()
