#!/bin/bash

# Aborta a execução se algum comando falhar
set -e

echo "=== 1. Criando ambiente virtual (venv) ==="
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "Ambiente virtual criado com sucesso."
else
    echo "Ambiente virtual já existente."
fi

echo "=== 2. Ativando o ambiente virtual ==="
source venv/bin/activate

echo "=== 3. Instalando dependências a partir do requirements.txt ==="
pip install --upgrade pip
pip install -r requirements.txt

echo "=== 4. Executando a Fase 1: data_pipeline.py ==="
python3 data_pipeline.py

echo "=== 5. Executando a Fase 2: train_models.py ==="
python3 train_models.py

echo "=== 6. Executando a Fase 3: evaluate_models.py ==="
python3 evaluate_models.py

echo "=== Processo concluído! Os dados e resultados foram gerados com sucesso. ==="
deactivate
