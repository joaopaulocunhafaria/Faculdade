# Sistema de Recomendação de Culturas Agrícolas

Trabalho Final da disciplina de **Inteligência Computacional** (CEFET-MG).
Projeto de **classificação multiclasse** que recomenda a cultura agrícola mais
adequada a partir de atributos de solo e clima, comparando de forma sistemática
três algoritmos: **Decision Tree**, **Random Forest** e **Multi-layer
Perceptron (MLP)**.

---

## 1. Base de dados

Utiliza-se o **Crop Recommendation Dataset**, disponível na Kaggle:

> https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset

- 2200 amostras, 7 atributos numéricos (`N`, `P`, `K`, `temperature`,
  `humidity`, `ph`, `rainfall`) e 1 variável de saída (`label`) com 22 classes.
- Base **balanceada** (100 amostras por cultura) e **sem valores ausentes**.
---

## 2. Requisitos

- Python 3.10 ou superior
- Sistema operacional baseado em Unix (Linux/macOS) para execução direta do script shell.

---

## 3. Execução Automatizada (run.sh)

Para facilitar e automatizar a execução de todo o projeto, disponibilizou-se o script shell `run.sh` na raiz do projeto. Ele realiza as seguintes operações automaticamente:
1. Cria o ambiente virtual (`venv`), caso não exista.
2. Ativa o ambiente virtual.
3. Instala e atualiza as dependências listadas em `requirements.txt`.
4. Executa ordenadamente os três scripts do projeto (`data_pipeline.py`, `train_models.py` e `evaluate_models.py`), gerando os dados limpos, os modelos treinados e os relatórios/gráficos finais de teste.

Antes de executar pela primeira vez, conceda permissão de execução ao script com:

```bash
chmod +x run.sh
```

Em seguida, para rodar todo o projeto com um único comando, execute:

```bash
./run.sh
```

---

## 4. Execução Manual dos Scripts (Opcional)

Caso prefira rodar os experimentos manualmente, certifique-se de ativar seu ambiente virtual, instalar os pacotes do `requirements.txt` e executar os scripts na seguinte ordem:

```bash
# 1) Preparação dos dados: EDA, padronização e divisão 60/20/20
python data_pipeline.py

# 2) Treinamento e busca de hiperparâmetros (avaliação na validação)
python train_models.py

# 3) Avaliação final no conjunto de teste (métricas + matrizes de confusão)
python evaluate_models.py
```

---

## 5. O que cada script faz

| Script | Função | Principais saídas |
|--------|--------|-------------------|
| `data_pipeline.py` | Carrega o dataset, faz a análise exploratória (EDA), padroniza as features (StandardScaler ajustado **só no treino**) e divide os dados em 60% treino / 20% validação / 20% teste (estratificado). | `output/treino.csv`, `output/validacao.csv`, `output/teste.csv`, `output/scaler.joblib`, `imgs/eda_*.png` |
| `train_models.py` | Treina os três modelos e busca hiperparâmetros na **validação**: profundidade (Decision Tree), nº de estimadores (Random Forest) e neurônios/camadas + taxa de aprendizado + épocas (MLP). Modelos estocásticos são repetidos com várias sementes (média ± desvio). | `output/validacao_*.csv`, `imgs/resultado_*.png`, `output/resumo_validacao.csv`, `output/modelo_*.joblib` |
| `evaluate_models.py` | Avaliação estrita no **teste** (20%) com múltiplas execuções: acurácia, precisão, revocação, F1-score e matriz de confusão, reportando média ± desvio. | `output/resultados_teste.csv`, `output/resultados_teste_execucoes.csv`, `imgs/matriz_confusao_*.png` |

**Divisão dos dados:** o conjunto de **teste** é usado exclusivamente na
avaliação final (`evaluate_models.py`), garantindo uma comparação justa entre os
algoritmos.



## . Estrutura de arquivos

```
.
├── data/
│   └── Crop_recommendation.csv  # (baixar da Kaggle)
├── data_pipeline.py             # Fase 1 — preparação dos dados
├── train_models.py              # Fase 2 — treino e hiperparâmetros
├── evaluate_models.py           # Fase 3 — avaliação no teste
├── artigo.tex                   # Fase 4 — artigo científico (LaTeX)
├── README.md
├── imgs/                        # figuras geradas (EDA, resultados, matrizes)
│   └── *.png
└── output/                      # dados processados, resultados e modelos
    ├── treino.csv, validacao.csv, teste.csv, scaler.joblib
    ├── validacao_*.csv, resumo_validacao.csv, modelo_*.joblib
    └── resultados_teste.csv, resultados_teste_execucoes.csv
```
